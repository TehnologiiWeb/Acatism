-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 05 Iun 2014 la 22:09
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `acatism`
--
CREATE DATABASE IF NOT EXISTS `acatism` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `acatism`;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `aplicari`
--

DROP TABLE IF EXISTS `aplicari`;
CREATE TABLE IF NOT EXISTS `aplicari` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idStud` int(11) NOT NULL,
  `idTema` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `etape`
--

DROP TABLE IF EXISTS `etape`;
CREATE TABLE IF NOT EXISTS `etape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nume` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Salvarea datelor din tabel `etape`
--

INSERT INTO `etape` (`id`, `nume`) VALUES
(1, 'Cercetare'),
(2, 'Proiectare'),
(3, 'Implementare'),
(4, 'Implementare'),
(5, 'Testare'),
(6, 'Documentatie');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `lecturi`
--

DROP TABLE IF EXISTS `lecturi`;
CREATE TABLE IF NOT EXISTS `lecturi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idTema` int(11) NOT NULL,
  `continut` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `profcodes`
--

DROP TABLE IF EXISTS `profcodes`;
CREATE TABLE IF NOT EXISTS `profcodes` (
  `nrInregistrare` varchar(255) NOT NULL,
  `ocupat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nrInregistrare`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `profcodes`
--

INSERT INTO `profcodes` (`nrInregistrare`, `ocupat`) VALUES
('12345', 1),
('12346', 0),
('12347', 0);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `profs`
--

DROP TABLE IF EXISTS `profs`;
CREATE TABLE IF NOT EXISTS `profs` (
  `id` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `numarInreg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `profs`
--

INSERT INTO `profs` (`id`, `nume`, `numarInreg`) VALUES
(8, 'euProf', '12345');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `progres`
--

DROP TABLE IF EXISTS `progres`;
CREATE TABLE IF NOT EXISTS `progres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tema` int(11) NOT NULL,
  `id_etapa` int(11) NOT NULL,
  `descriere` varchar(1000) NOT NULL,
  `realizare` int(11) NOT NULL DEFAULT '0',
  `deadline` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Salvarea datelor din tabel `progres`
--

INSERT INTO `progres` (`id`, `id_tema`, `id_etapa`, `descriere`, `realizare`, `deadline`) VALUES
(1, 1, 1, 'Cercetare', 0, '2014-06-12'),
(2, 1, 2, 'Proiectaree', 0, '2014-06-30'),
(3, 1, 3, 'Implementaree', 0, '2014-07-18'),
(4, 1, 4, 'Testareee', 0, '2014-07-31'),
(5, 1, 5, 'Documentatiee', 0, '2014-08-21');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `requests`
--

DROP TABLE IF EXISTS `requests`;
CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tema` int(11) NOT NULL,
  `id_student` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `studentcodes`
--

DROP TABLE IF EXISTS `studentcodes`;
CREATE TABLE IF NOT EXISTS `studentcodes` (
  `nrMatricol` varchar(255) NOT NULL,
  `ocupat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nrMatricol`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `studentcodes`
--

INSERT INTO `studentcodes` (`nrMatricol`, `ocupat`) VALUES
('1234', 1),
('1235', 1);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int(11) NOT NULL,
  `nume` varchar(255) NOT NULL,
  `anStudiu` int(11) NOT NULL,
  `grupa` varchar(5) NOT NULL,
  `tipStudii` varchar(20) NOT NULL,
  `nrMatricol` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `students`
--

INSERT INTO `students` (`id`, `nume`, `anStudiu`, `grupa`, `tipStudii`, `nrMatricol`) VALUES
(7, 'EU', 1, '2B3', 'Licenta', '1235');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `temealese`
--

DROP TABLE IF EXISTS `temealese`;
CREATE TABLE IF NOT EXISTS `temealese` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idStud` int(11) NOT NULL,
  `idProf` int(11) NOT NULL,
  `idTema` int(11) NOT NULL,
  `sesiune` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Salvarea datelor din tabel `temealese`
--

INSERT INTO `temealese` (`id`, `idStud`, `idProf`, `idTema`, `sesiune`) VALUES
(1, 7, 8, 1, '2014-06-12');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `temepropuse`
--

DROP TABLE IF EXISTS `temepropuse`;
CREATE TABLE IF NOT EXISTS `temepropuse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idProf` int(11) NOT NULL,
  `description` varchar(2000) NOT NULL,
  `titlu` varchar(255) NOT NULL,
  `tipTema` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Salvarea datelor din tabel `temepropuse`
--

INSERT INTO `temepropuse` (`id`, `idProf`, `description`, `titlu`, `tipTema`) VALUES
(1, 8, 'Pentru incercari', 'Demo', 0);

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `typeID` int(11) NOT NULL,
  `github` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Salvarea datelor din tabel `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `typeID`, `github`) VALUES
(7, 'eu@test.com', '4829322d03d1606fb09ae9af59a271d3', 0, 'AndreeaUrsulescu'),
(8, 'euProf@test.com', '4829322d03d1606fb09ae9af59a271d3', 1, 'calincrist');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
